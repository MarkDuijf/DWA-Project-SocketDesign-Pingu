This is the readme for the demo from the 'socketDesigner'.
In here, a small description and a how-to will be given.
Do note, the demo only includes the generated socket.io code, code for a basic server, a package.json and the used yaml code.
There will be no html file to test the client side socket.io code.

The socket.io code includes three messages, of which one requires you to make a room and another one requires you to add users.
It is recommended that you have atleast some basic understanding on how socket.io works.
You are required to use nodeJS with this program.

How to install and test the demo:
)open a terminal and navigate to the map where the package.json is
)once you arrive, use the 'npm install' command. if it fails try 'sudo npm install'
)once it is installed, use the terminal and use either the 'node server.js' command or the 'nodemon server.js' command.
)once the server runs open a browser and navigate to 'localhost:3000'. this is where the server runs.

once all these steps have been followed you should be able to use the demo.

- the socketDesigner team
